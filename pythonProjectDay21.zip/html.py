"""
HTML

- Hyper Text Mark UP Language
- Not a Programming Language
- Markup Language for creating webpages/documents
- building blocks of the web

-- It does not need an server
- file must end with the .html extension
- Runs in a web browser
- index.html is the root/home page of the website

syntax
<tagname>content</tagname>

<h1>About Us</h1>
<p>This is a paragraph</p>
<br/>
<br>

Basic Tags
<!Doctype> defines the document type
<html> defines an HTML document
<head>
<title>
<body>
<h1> to <h6>
<p>
<br>
<hr>
<!--> - comment in html
"""

"""
python program to capture firstname, lastname
and age

and write it in a html file
file handling

a.html
b.html
c.html
"""

firstname = input("enter the first name: ")
lastname = input("enter the last name: ")
age = input("enter the age: ")
html_str = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome Page</title>
</head>
<body>
<picture>
<img src="img.png">
</picture>
<h1>Welcome {firstname}, {lastname}</h1>
<p>Your age is <mark><del>{age}</del></mark></p>
</body>
</html>
"""
f =  open("welcome.html","w")
f.write(html_str)
f.close()

"""
Formatting Tags

<blockquote>
<abbr>
<cite> 
<b>
<i>
<em>
<strong>
<small>
<sub>
<sup>
<ins>
<del>
<mark>

Forms and Inputs
<form>
<input>
<output>
<textarea>
<button>
<select>
<option>
<label>

Images
<img>
<map>
<area>
<canvas>
<figure>
<figcaption>
<picture>
<svg>

Audio/Video
<audio>
<source>
<track>
<video>

Links
<a>
<link>
<nav>

HTML TABLES:
<table>
    <thead>
        <th></th>
    </thead>
    <tbody>
        <td></td>
    </tbody>
</table>
"""


"""
Write a program for creating the html table ( create html file ) from the python program
1. get data from https://worldweather.wmo.int/en/json/full_city_list.txt through requests module
    import requests
    data = requests.get("https://worldweather.wmo.int/en/json/full_city_list.txt")
    print(data.text)
2. create a html string with html table using python string datatype
3. write the html string to the html file
4. create your own css and link it with the html file created above.
"""
